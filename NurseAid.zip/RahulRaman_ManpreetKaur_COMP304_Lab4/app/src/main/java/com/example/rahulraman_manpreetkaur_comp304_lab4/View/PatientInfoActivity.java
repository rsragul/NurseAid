package com.example.rahulraman_manpreetkaur_comp304_lab4.View;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.rahulraman_manpreetkaur_comp304_lab4.R;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.PatientTable;
import com.example.rahulraman_manpreetkaur_comp304_lab4.ViewModel.PatientViewModel;

import java.util.ArrayList;
import java.util.List;

public class PatientInfoActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<PatientTable> patientsList = new ArrayList<PatientTable>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_info);
        //getting the recyclerview from xml
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        PatientViewModel viewModel = ViewModelProviders.of(this).get(PatientViewModel.class);

        viewModel.getAllPatient().observe(this, new Observer<List<PatientTable>>() {
            @Override
            public void onChanged(List<PatientTable> patients) {
                Log.e("Patientsss", patients.toString());
                patientsList.addAll(patients);
                PatientAdapter adapter = new PatientAdapter(getApplication(), patientsList);
                //setting adapter to recyclerview
                recyclerView.setAdapter(adapter);
            }
        });
    }
}