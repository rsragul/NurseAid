package com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface PatientDao  {

    //Monitoring Query Result Changes with Live Data
    @Query("select * from PatientDetails ")
    LiveData<List<PatientTable>> getAllPatient();

    @Insert
    void insert(PatientTable person);

    @Update
    void update(PatientTable person);

    @Query("DELETE FROM PatientDetails")
    void deleteAll();

    @Query("select * from PatientDetails where PatientId = :patientId")

    LiveData<PatientTable> getSelectedPatient(int patientId);
}
