package com.example.rahulraman_manpreetkaur_comp304_lab4.ViewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.rahulraman_manpreetkaur_comp304_lab4.Repository.PatientRepository;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.PatientTable;

import java.util.List;


public class PatientViewModel extends AndroidViewModel {
    // calling repository tasks and
    // sending the results to the Activity
    private PatientRepository patientRepository;
    private LiveData<Integer> insertResult;
    private LiveData<List<PatientTable>> allPatient;
    //
    public PatientViewModel(@NonNull Application application) {
        super(application);
        patientRepository = new PatientRepository(application);
        insertResult = patientRepository.getInsertResult();
        allPatient = patientRepository.getAllPatient();
    }
    //calls repository to insert a patient
    public void insert(PatientTable patient) {
        patientRepository.insert(patient);
    }

    public void update(PatientTable patient) {
        patientRepository.update(patient);
    }
    //gets insert results as LiveData object
    public LiveData<Integer> getInsertResult() {
        return insertResult;
    }
    //returns query results as live data object
    public LiveData<List<PatientTable>> getAllPatient() { return allPatient; }
}