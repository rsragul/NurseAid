package com.example.rahulraman_manpreetkaur_comp304_lab4.ViewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.rahulraman_manpreetkaur_comp304_lab4.Repository.TestRepository;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.TestTable;

import java.util.List;


public class TestViewModel extends AndroidViewModel {
    // calling repository tasks and
    // sending the results to the Activity
    private TestRepository testRepository;
    private LiveData<Integer> insertResult;
    private LiveData<List<TestTable>> allTest;
    //
    public TestViewModel(@NonNull Application application) {
        super(application);
        testRepository = new TestRepository(application);
        insertResult = testRepository.getInsertResult();
        allTest = testRepository.getAllTest();
    }
    //calls repository to insert a patient
    public void insert(TestTable test) {
        testRepository.insert(test);
    }
    //gets insert results as LiveData object
    public LiveData<Integer> getInsertResult() {
        return insertResult;
    }
    //returns query results as live data object
    public LiveData<List<TestTable>> getAllPatient() { return allTest; }

    public LiveData<TestTable> getSpecificTest(int testId) { return testRepository.getSelectedTest(testId); }
}
