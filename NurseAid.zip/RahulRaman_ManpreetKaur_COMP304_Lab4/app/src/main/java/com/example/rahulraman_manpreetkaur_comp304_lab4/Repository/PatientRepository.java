package com.example.rahulraman_manpreetkaur_comp304_lab4.Repository;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.PatientDao;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.PatientDatabase;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.PatientTable;

import java.util.List;


public class PatientRepository {
    private final PatientDao patientDao;
    private MutableLiveData<Integer> insertResult = new MutableLiveData<>();
    private LiveData<List<PatientTable>> patientList;
    private LiveData<List<PatientTable>> selectedPatient;
    //
    public PatientRepository(Context context) {
        //create a database object
        PatientDatabase db = PatientDatabase.getInstance(context);
        //create an interface object
        patientDao = db.patientDao();
        //call interface method
        patientList = patientDao.getAllPatient();
    }
    // returns query results as LiveData object
    public LiveData<List<PatientTable>> getAllPatient() {
        return patientList;
    }
    public LiveData<PatientTable> getSelectedPatient(int patientId) {
        return patientDao.getSelectedPatient(patientId);
    }
    //inserts a person asynchronously
    public void insert(PatientTable patient) {
        insertAsync(patient);
    }

    public void update(PatientTable patient) {
        updateAsync(patient);
    }
    // returns insert results as LiveData object
    public LiveData<Integer> getInsertResult() {
        return insertResult;
    }

    private void insertAsync(final PatientTable patient) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    patientDao.insert(patient);
                    insertResult.postValue(1);
                } catch (Exception e) {
                    insertResult.postValue(0);
                }
            }
        }).start();
    }

    private void updateAsync(final PatientTable patient) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    patientDao.update(patient);
                    insertResult.postValue(1);
                } catch (Exception e) {
                    insertResult.postValue(0);
                }
            }
        }).start();
    }
}
