package com.example.rahulraman_manpreetkaur_comp304_lab4.ViewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.rahulraman_manpreetkaur_comp304_lab4.Repository.LoginRepository;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.LoginTable;

import java.util.List;

public class LoginViewModel extends AndroidViewModel {

    private LoginRepository repository;
    private LiveData<List<LoginTable>> getAllData;
    private LiveData<Integer> insertResult;

    public LoginViewModel(@NonNull Application application) {
        super(application);

        repository = new LoginRepository(application);
        getAllData = repository.getAllData();
        insertResult = repository.getInsertResult();
    }

    public LiveData<Integer> getInsertResult() {
        return insertResult;
    }

    public void insert(LoginTable data) {
        repository.insertData(data);
    }

    public LiveData<List<LoginTable>> getGetAllData() {
        return getAllData;
    }

}

