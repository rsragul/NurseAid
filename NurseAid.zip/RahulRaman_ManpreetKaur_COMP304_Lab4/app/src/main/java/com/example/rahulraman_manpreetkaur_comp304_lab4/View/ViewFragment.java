package com.example.rahulraman_manpreetkaur_comp304_lab4.View;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.rahulraman_manpreetkaur_comp304_lab4.R;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.TestTable;
import com.example.rahulraman_manpreetkaur_comp304_lab4.ViewModel.TestViewModel;

public class ViewFragment extends Fragment {

    TestViewModel viewModel;
    private Button viewInfoButton;
    private TextView testIdEditText, patientIdEditText, nurseIdEditText, bplEditText, bphEditText, temperatureEditText;
    EditText testId;
    boolean isVisible = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_view, container, false);

        patientIdEditText = (TextView) rootView.findViewById(R.id.viewt2);
        testIdEditText = rootView.findViewById(R.id.viewt1);
        nurseIdEditText = rootView.findViewById(R.id.viewt3);
        bplEditText = rootView.findViewById(R.id.viewt4);
        bphEditText = rootView.findViewById(R.id.viewt5);
        temperatureEditText = rootView.findViewById(R.id.viewt6);
        viewInfoButton = (Button) rootView.findViewById(R.id.viewinfobutton);
        testId = rootView.findViewById(R.id.viewet1);
        viewModel =  ViewModelProviders.of(this).get(TestViewModel.class);

        if(!isVisible) {
            patientIdEditText.setVisibility(View.INVISIBLE);
            testIdEditText.setVisibility(View.INVISIBLE);
            nurseIdEditText.setVisibility(View.INVISIBLE);
            bplEditText.setVisibility(View.INVISIBLE);
            bphEditText.setVisibility(View.INVISIBLE);
            temperatureEditText.setVisibility(View.INVISIBLE);
        }

        viewInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewModel.getSpecificTest(Integer.parseInt(testId.getText().toString())).observe(getViewLifecycleOwner(), new Observer<TestTable>() {
                    @Override
                    public void onChanged(TestTable test) {
                        if(test != null){
                            isVisible = true;
                            patientIdEditText.setVisibility(View.VISIBLE);
                            testIdEditText.setVisibility(View.VISIBLE);
                            nurseIdEditText.setVisibility(View.VISIBLE);
                            bplEditText.setVisibility(View.VISIBLE);
                            bphEditText.setVisibility(View.VISIBLE);
                            temperatureEditText.setVisibility(View.VISIBLE);
                            patientIdEditText.setText("Patient ID:    " + test.getPatientId());
                            testIdEditText.setText("Test ID:         " + test.getTestId());
                            nurseIdEditText.setText("Nurse ID:     " + test.getNurseId());
                            bplEditText.setText("BPL:              " + test.getBPL());
                            bphEditText.setText("BPH:              " + test.getBPH());
                            temperatureEditText.setText("Temperature:" + test.getTemperature());

                        } else {
                            patientIdEditText.setVisibility(View.INVISIBLE);
                            testIdEditText.setVisibility(View.INVISIBLE);
                            nurseIdEditText.setVisibility(View.INVISIBLE);
                            bplEditText.setVisibility(View.INVISIBLE);
                            bphEditText.setVisibility(View.INVISIBLE);
                            temperatureEditText.setVisibility(View.INVISIBLE);
                            Toast.makeText(getActivity(), "No data found for this test ID", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        return rootView;
    }
}
