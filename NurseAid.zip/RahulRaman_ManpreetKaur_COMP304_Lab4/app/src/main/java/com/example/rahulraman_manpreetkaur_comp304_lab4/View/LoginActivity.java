package com.example.rahulraman_manpreetkaur_comp304_lab4.View;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.rahulraman_manpreetkaur_comp304_lab4.R;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.LoginTable;
import com.example.rahulraman_manpreetkaur_comp304_lab4.ViewModel.LoginViewModel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    private LoginViewModel viewModel;
    private Button loginButton, signupButton;
    private EditText usernameEditText, passwordEditText;
    String username, password;
    LoginTable loginData;
    boolean doesMatch = false;
    Map<Integer, String> userDetails = new HashMap<>();
    public static final String MY_PREFS_NAME = "MyPrefsFile";
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        usernameEditText = findViewById(R.id.logint1);
        passwordEditText = findViewById(R.id.logint2);
        loginButton = findViewById(R.id.loginb1);
        signupButton = findViewById(R.id.loginb2);
        viewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        loginData = new LoginTable();

        viewModel.getGetAllData();
        viewModel.getGetAllData().observe(this, new Observer<List<LoginTable>>() {
            @Override
            public void onChanged(List<LoginTable> result) {
                for(LoginTable data : result){
                    userDetails.put(data.getNurseId(), data.getPassword());
                }
            }
        });
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = usernameEditText.getText().toString();
                password = passwordEditText.getText().toString();
                for(Integer key : userDetails.keySet()){
                    if(String.valueOf(key).equals(username) && userDetails.get(key).equals(password)){
                        doesMatch = true;
                    }
                }

                if(doesMatch) {
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid login details, please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signupButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });
    }
}
