package com.example.rahulraman_manpreetkaur_comp304_lab4.Repository;


import android.app.Application;
import android.content.Context;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.TestDao;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.TestDatabase;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.TestTable;
import com.example.rahulraman_manpreetkaur_comp304_lab4.View.TestFragment;

import java.util.List;


public class TestRepository {
    private final TestDao testDao;
    private MutableLiveData<Integer> insertResult = new MutableLiveData<>();
    private LiveData<List<TestTable>> testList;
    private LiveData<List<TestTable>> selectedTest;
    //
    public TestRepository(Context context) {
        //create a database object
        TestDatabase db = TestDatabase.getDatabase(context);
        //create an interface object
        testDao = db.testDao();
        //call interface method
        testList = testDao.getAllTests();
    }
    // returns query results as LiveData object
    public LiveData<List<TestTable>> getAllTest() {
        return testList;
    }
    public LiveData<TestTable> getSelectedTest(int testId)
    {
        return testDao.getSelectedTest(testId);
    }
    //inserts a person asynchronously
    public void insert(TestTable test) {
        insertAsync(test);
    }
    // returns insert results as LiveData object
    public LiveData<Integer> getInsertResult() {
        return insertResult;
    }

    private void insertAsync(final TestTable test) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    testDao.insertDetails(test);
                    insertResult.postValue(1);
                } catch (Exception e) {
                    insertResult.postValue(0);
                }
            }
        }).start();
    }
}
