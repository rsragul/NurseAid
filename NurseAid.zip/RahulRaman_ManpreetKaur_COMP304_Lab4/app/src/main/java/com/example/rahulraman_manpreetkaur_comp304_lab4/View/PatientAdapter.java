package com.example.rahulraman_manpreetkaur_comp304_lab4.View;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.rahulraman_manpreetkaur_comp304_lab4.R;
import com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase.PatientTable;

import java.util.List;

public class PatientAdapter extends RecyclerView.Adapter<PatientAdapter.PatientViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<PatientTable> patientList;

    //getting the context and product list with constructor
    public PatientAdapter(Context mCtx, List<PatientTable> patientList) {
        this.mCtx = mCtx;
        this.patientList = patientList;
    }

    @Override
    public PatientViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.acitvivty_layout_patients, parent, false);
        return new PatientViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PatientViewHolder holder, int position) {
        //getting the product of the specified position
        PatientTable patient = patientList.get(position);

        //binding the data with the viewholder views
        holder.textViewPatientName.setText(" Patient Name:       " + patient.getFirstName() + " " + patient.getLastName());
        holder.textViewPatientId.setText(" Patient ID:             " + patient.getPatientId());
        holder.textViewDepartment.setText(" Patient Department:         " + patient.getDepartment());
        holder.textViewNurseId.setText(" Nurse ID:                 " + patient.getNurseId());
        holder.textViewPatientRoom.setText(" Patient Room:        " + patient.getRoom());
    }


    @Override
    public int getItemCount() {
        return patientList.size();
    }


    class PatientViewHolder extends RecyclerView.ViewHolder {

        TextView textViewPatientName, textViewPatientId, textViewDepartment, textViewNurseId, textViewPatientRoom;

        public PatientViewHolder(View itemView) {
            super(itemView);

            textViewPatientName = itemView.findViewById(R.id.showPatientName);
            textViewPatientId = itemView.findViewById(R.id.showPatientId);
            textViewDepartment = itemView.findViewById(R.id.showPatientDepartment);
            textViewNurseId = itemView.findViewById(R.id.showNurseId);
            textViewPatientRoom = itemView.findViewById(R.id.showRoom);
        }
    }
}