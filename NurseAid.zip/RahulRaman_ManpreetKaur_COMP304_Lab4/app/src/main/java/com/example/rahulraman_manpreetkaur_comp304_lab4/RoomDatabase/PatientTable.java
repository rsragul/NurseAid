package com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "PatientDetails")
public class PatientTable {

    public PatientTable() {}

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "PatientId")
    private int patientId;

    @ColumnInfo(name = "FirstName")
    private String firstName;

    @ColumnInfo(name = "LastName")
    private String lastName;

    @ColumnInfo(name = "Department")
    private String department;

    @ColumnInfo(name = "NurseId")
    private int nurseId;

    @ColumnInfo(name = "Room")
    private String room;

    public PatientTable(String firstName, String lastName, String department, int nurseId, int patientId, String room) {
        this.patientId = patientId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = department;
        this.nurseId = nurseId;
        this.room = room;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int PatientId) {
        this.patientId = PatientId;
    }

    public String getFirstName() {
        return firstName;
    }



    public String getLastName() {
        return lastName;
    }



    public String getDepartment() {
        return department;
    }



    public int getNurseId() {
        return nurseId;
    }



    public String getRoom() {
        return room;
    }

    public void setFirstName(String FirstName) {
        this.firstName = FirstName;
    }

    public void setLastName(String LastName) {
        this.lastName = LastName;
    }

    public void setDepartment(String Department) {
        this.department = Department;
    }

    public void setNurseId(int NurseId) {
        this.nurseId = NurseId;
    }

    public void setRoom(String Room) {
        this.room = Room;
    }
}
