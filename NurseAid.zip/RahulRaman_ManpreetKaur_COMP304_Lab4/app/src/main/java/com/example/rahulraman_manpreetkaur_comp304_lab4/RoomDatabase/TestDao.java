package com.example.rahulraman_manpreetkaur_comp304_lab4.RoomDatabase;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface TestDao  {

    @Insert
    void insertDetails(TestTable data);

    @Query("select * from TestDetails")
    LiveData<List<TestTable>> getAllTests();

    @Query("delete from TestDetails")
    void deleteAllData();

    @Query("select * from TestDetails where TestId = :testId")
    LiveData<TestTable> getSelectedTest(int testId);
}
